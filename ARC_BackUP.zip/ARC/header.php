<style>
    .header-background{
        margin-top: 80px;
        width: 100%;
        height: 75vh;
        object-fit: contain;
        position: absolute;
        top: 0;
        left: 0;
    }

    .backgroundfoto{
        width: 100%;
        height: 100%;
        
    }
</style>

<div class="header-background">
    <img class="backgroundfoto" src="assets/img/hero/Sem Título-1-Recuperado-Recuperado.png" alt="">
</div>