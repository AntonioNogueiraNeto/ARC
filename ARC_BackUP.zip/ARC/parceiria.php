      <!-- ======= About Section ======= -->
      <style>
          .sectionabout2 {
              background-image: url("assets/img/svg/about2.png");


              background-repeat: no-repeat;
              background-size: cover;
          }

          @media screen and (max-width: 768px) {
              .sectionabout2 {
                  background-image: url("assets/img/svg/mobileparceria2.png");


                  background-repeat: no-repeat;
                  background-size: cover;
              }
          }
      </style>


      <section id="about" class="about sectionabout2">
          <div class="container">
              <div class="row">

                  <div class="col-xl-7 col-lg-6 es d-flex flex-column align-items-stretch justify-content-center py-5 px-lg-5">
                      <h2 data-aos="fade-up"> Uma Parceria Estratégica com a ARC Transportes e Logística</h2>


                      <p data-aos="fade-up" class="text-left">
                          Na <strong>ARC Transportes e Logística </strong>, comprometemo-nos a oferecer uma parceria sólida e confiável para atender às suas necessidades de transporte. Diferenciamo-nos através de:
                      </p>
                      <style>
                          .parceiria {
                              margin-top: 20px;
                          }
                      </style>
                      <div class="parceiria" data-aos="fade-up">
                          <h4 class="title text-left">Equipe Dedicada</h4>

                      </div>

                      <div class="parceiria" data-aos="fade-up" data-aos-delay="100">
                          <h4 class="title text-left">Conformidade Fiscal</h4>

                      </div>

                      <div class="parceiria" data-aos="fade-up" data-aos-delay="100">
                          <h4 class="title text-left">Atualização Contínua</h4>

                      </div>

                      <div class="parceiria" data-aos="fade-up" data-aos-delay="100">
                          <h4 class="title text-left">Compromisso com a Segurança</h4>

                      </div>

                      <div class="parceiria" data-aos="fade-up" data-aos-delay="100">
                          <h4 class="title text-left">Acompanhamento Integral</h4>

                      </div>
                  </div>



                  <div class="col-xl-5 col-lg-6 video-box2 d-flex justify-content-center align-items-stretch position-relative" data-aos="fade-right">
                      <!-- <a href="https://www.youtube.com/watch?v=jDDaplaOz7Q" class="glightbox play-btn mb-4"></a> -->
                  </div>
              </div>
          </div>
      </section>
      <style>

      </style>
      <div class="divisao">


      </div>


      <!-- End About Section -->