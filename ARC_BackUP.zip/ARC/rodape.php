<style>
    .rodape {
        background-color: #000947;
        color: white;
        text-align: center;
        padding: 10px;
        justify-content: center;
        align-self: center;
        vertical-align: middle;
        font-family: "Roboto", sans-serif;
    }

    .rodape a {
        color: white;
        font-weight: bold;
    }
</style>


<div class="rodape">
    <p> Desenvolvido por <a href="https://uhlelotecnologia.com.br/" target="_blank">uHLelo Tecnologia</a>


</div>