   <style>
       .case-bg {
           color: white !important;
       }

       .exemplo h2 {
           font-size: 40px;
           font-weight: 700px;
           font-weight: bold;
           color: white !important
       }

       .exemplo h3 {
           color: white !important;
           font-weight: bold;

       }

       .texto {
           text-align: center;
       }

       .case-bg {
           background-color: #000947;
       }
   </style>

   <section class="case-bg">
       <div class="container" data-aos="fade-up">

           <div class="section-title exemplo" data-aos="fade-up">
               <h2>CASE</h2>
               <h3> Transportes de reatores </h3>

           </div>

           <!-- <div>
               <style>
                   .imagecase {
                       background-color: white;
                       display: flex;
                       width: 80%;
                       margin: auto;
                       align-items: center;
                       padding: 20px;
                       margin-bottom: 40px;
                   }
               </style>
               <img class="imagecase" src="assets/img/frota/REATORES.jpg" alt="">
           </div> -->


           <div class="texto">
               Trinta e três embarques, 280 mil km percorridos.
               <br>
               Coletar, estocar e transportar foram as exigências solicitadas.
               <br>
               Diâmetro da carga: 4,10m; altura: 5,30m, o transporte superdimensionado
               para longas distâncias é sempre repleto de surpresas.
               <h4 style="padding-top: 20px;">A ARC Transporte é especialista em cargas de grande porte</h4>
           </div>




       </div>

   </section>